<?php
return[
	'blog'=>'Блог',
	'message'=>'Сообщение',
	'title'=>'Заглавие',
	];
?>