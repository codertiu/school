<?php
return[
	'blog'=>'Blog',
	'message'=>'Xabar',
	'title'=>'Mavzu',
	];
?>