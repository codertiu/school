<?php
return[
	'blog'=>'Blog',
	'message'=>'Message',
	'title'=>'Title',
	];
?>